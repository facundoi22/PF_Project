var app = angular.module('MobileAngularUiExamples', [
  'ngRoute',
  'mobile-angular-ui',
  ]);
  
 //El ruteo de las vistas	

app.config(function($routeProvider) {
  $routeProvider.when('/',   
	{templateUrl: 'vistas/home.html', reloadOnSearch: false});
  $routeProvider.when('/cuatri',  
	{templateUrl: 'vistas/cuatri.html', reloadOnSearch: false});
  $routeProvider.when('/faq', 
	{templateUrl: 'vistas/faq.html', reloadOnSearch: false});
  $routeProvider.when('/notas', 
	{templateUrl: 'vistas/notas.html', reloadOnSearch: false});

	$routeProvider.otherwise({
			redirectTo: '/'
		});
 
});

//A partir de acá empieza el controller	

app.controller("ControladorPrincipal", function($scope, $http) {

//La primera parte es de la sección Materias 

	$scope.materias1 = [];
	$scope.materias2 = [];
	$scope.materias3 = [];
 

		$scope.materias1[0]={nombre:'Maquetación y Desarrollo Web', estado: 'Por cursar'};   
		$scope.materias1[1]={nombre:'Diseño de Interfaces', estado: 'Por cursar'};   
		$scope.materias1[2]={nombre:'Experiencia del Usuario', estado: 'Por cursar'}; 
		$scope.materias1[3]={nombre:'Introducción al diseño gráfico', estado: 'Por cursar'}; 								
		$scope.materias1[4]={nombre:'Lógica de la Programación', estado: 'Por cursar'};  
		
		
		$scope.materias2[0]={nombre: 'Interacción con Dispositivos Móviles', estado: 'Por cursar'};  
		$scope.materias2[1]={nombre:'Programación I', estado: 'Por cursar'};  
		$scope.materias2[2]={nombre:'Diseño Vectorial', estado: 'Por cursar'};  
		$scope.materias2[3]={nombre: 'Diseño Gráfico para Web', estado: 'Por cursar'};  
		$scope.materias2[4]={nombre: 'Usabilidad y Funcionalidad I', estado: 'Por cursar'};  
		
		$scope.materias3[0]={nombre:'Aplicaciones para Dispositivos Móviles', estado: 'Por cursar'};  
		$scope.materias3[1]={nombre: 'Sistemas Operativos I', estado: 'Por cursar'}; 
		$scope.materias3[2]={nombre: 'Programación II', estado: 'Por cursar'};  
		$scope.materias3[3]={nombre: 'Usabilidad y Funcionalidad II', estado: 'Por cursar'};     
		$scope.materias3[4]={nombre: 'Diseño Interactivo', estado: 'Por cursar'}; 



	$scope.estados = [ {estado:'Por cursar'},
						{estado:'Cursando'},
						{estado:'Adeuda final'},
						{estado:'Final Aprobado'}]; 
						
	
//A partir de acá empieza lo de la sección FAQ					
						
						
	 $scope.preguntas = [ 
								{Pregunta: '¿Cómo hago para rendir un final?', Respuesta: 'Una vez cursada la materia, y tener aprobados la totalidad de los TP tenés la posibilidad de rendir el final de la materia. Para esto, tenés que esperar los períodos de inscripción a finales, hay 5 por año. Para inscribirte tenés que pagar en tesorería el "derecho a examen" que tiene un valor de $100, 48hs antes de la mesa. Las fechas figuran en el DV panel, en la sección "Inscripción a finales" '},    
								{Pregunta: '¿Tengo que presentarme en mesa de finales si promocioné?', Respuesta: 'Sí. Cuando promocionás una materia, tenés que proceder del mismo modo que si fueras a rendir un final: debés abonar el derecho a examen, y anotarte en el DV panel. Al momento de la mesa debés presentarte, pero sólo a fines burocráticos, ya que no se te evalúa de ninguna forma. Simplemente el profesor titular sube la nota al sistema, una vez que das el presente'},  
								{Pregunta: '¿Cómo se puede pagar la cuota?', Respuesta: 'Podés pagarla en efectivo o con tarjeta presentándote en ventanilla de tesorería, en los horarios de atención, de 10 a 21 horas, en el segundo piso del edificio 3. O a través de transferencia bancaria, para esto tenés que contarcarte por mail con tesorería, ellos te brindarán los datos de la cuenta. Una vez realizada la transferencia, debés enviar el comprobante, aclarándo qué fue lo que abonaste'},  
								{Pregunta: '¿Cómo puedo obtener una materia por equivalencia?', Respuesta: 'Primero, debés presentarte en Secretaria de Alumnos para informar a la Jefa del sector e iniciar el trámite. Luego, debés conseguir la currícula de la materia, autorizada como legítima por las autoridades correspondientes. Una vez presentada la documentación, será evaluada tu solicitud y en caso de que se apruebe, debés pagar una canón en tesorería de aprox. $500 y listo, se te otorgará la materia por equivalencia '},  						
								{Pregunta: '¿Cuántas materias puedo cursar por cuatrimestre', Respuesta: 'Podés cursar hasta 6 materias por cuatrimestre. Tené en cuenta que existen materias con correlatividades (por ejemplo Programación I es correlativa de Programación II). Por eso, a partir del segundo cuatrimestre, cada vez que quieras anotarte en una materia, debés controlar si esa asignatura tiene correlatividades y en caso afirmativo, si tenés la cursada aprobada de dicha materia (no es necesario tener el final aprobado)'},  
								{Pregunta: '¿Cuándo se me vencen los finales', Respuesta: 'Tenés un total de 10 llamados para rendir el final, antes de que se te venza. Corresponde a un plazo de 2 años (después de finalizada la cursada). Tenés 3 oportunidades para rendir el final, en caso de desaprobar las 3 tenés que recursar la materia nuevamente'}
					]; 
					

//A partir de acá es de la sección notas
		
	$scope.datos_en_push = [];

    $scope.notas = {};

    //$http.get("http://localhost/FinalLeonardoWeb2.0/php/listarnotas.php")
	$http.get("http://www.cuantaskcal.com/beta/listarnotas.php")
					.success(function (data) {

                            //La variable que nos devuelve el PHP es un Array de Objetos
							//alert('data = ' + data);

	                        //Tomamos los datos tal como están en el Local Storage (LS)
						    var notas_string = localStorage.getItem("mis_notas");

    	                    //Convertimos los datos del LS en un Array de Objetos
	                        var notas_fromJson = angular.fromJson(notas_string);

	                        //Variable "estado" nos va a servir para determinar si hay informacion en DB y/o en LS
						    /*
						    * 1 = Hay info en DB y LS
						    * 2 = Hay info sólo en DB
						    * 3 = Hay info sólo en LS
						    * 4 = No hay info en ningún lado
						    * */

							if(data != "undefined" && data != null && notas_string != "undefined" && notas_string != null){
								var estado = 1;
                            }
                            else if (data != "undefined" && data != null){
								var estado = 2;
                            } else if(notas_string != "undefined" && notas_string != null){
								var estado = 3;
                            }
							else{
								var estado = 4;
                        	}

							console.log('valor de Estado de carga de lista = ' + estado);

							if(estado == '1'){

							//Si el Array que recibo de la Base es Mayor o igual que el array que formamos
						    // con los datos del LS entonces piso los datos del LS con los de la Base
						    	if(data.length >= notas_fromJson.length) {

                                    console.log('entro al if listado');

										//Entonces acá es donde piso los datos del LS. Con "angular.toJson()" lo que hago es pasar el
									    // Array de Objetos que me devolvió el php de la Base a un String como los que acepta el LS
                            	    	localStorage.setItem("mis_notas", angular.toJson(data));

                            	    	var notas_fromJson = data;

                            	    	//Recorremos el Array de Objetos con un for. Por cada Objeto hacemos un push
									  // en nuestra Variable Global "$scope.datos_en_push"
                            	     	for (var j = 0; j < notas_fromJson.length; j++) {
                            	        	$scope.datos_en_push.push(angular.copy(notas_fromJson[j]));
                            	    	}
                            	}

                            	//Si el Array que recibo de la Base es Menor al array que formamos con los datos del LS
								// entonces tomo esos datos para actualizar el datos_en_push
                            	else
								{

                            	    console.log('entro al else listado');

									//Tomo los datos del LS tal como vienen
									var notas_string = localStorage.getItem("mis_notas");

                            	    //Si LS tiene datos...
									//if (notas_string != "undefined" && notas_string != null){

										//Convierto el string en un Array de Objetos
										var notas_fromJson = angular.fromJson(notas_string);

                            	        //Recorro con un for el array de Objetos sacado del LS
                            	        for (var p = 0; p < notas_fromJson.length; p++){

                            	        	//Por cada Objeto hago un push en la variable "$scope.datos_en_push"
                            	        	$scope.datos_en_push.push(angular.copy(notas_fromJson[p]));

                            	        	//Inicializo esta variable auxiliar en "true"
                            	            var check = true;
                            	            var cont = 0;

                            	            //Ahora voy a recorrer El Array de Obj de la Base (bucle anidado)
											for(var q = 0; q < data.length; q++){
                            	                console.log(data[q].idnota);
                            	                console.log(data);

                            	                //Si encuentro una coincidencia entre valores de ID de Objetos de ambos Arrays
												//el de la Base y el de LS paso check a Falso. COn una coincidencia ya sé que no lo tengo
												//que insertar en la Base porque ya figura
                            	                if(data[q].idnota == notas_fromJson[p].idnota){
                            	                    var check = false;
												}

											}

											//Entonces si NO hubo ninguna coincidencia Check se mantuvo en "true", por
											// lo tanto es necesario insertar esa info en Base
											if(check){
                            	                //Preparo la información a enviar
												var tituloEnviar = notas_fromJson[p].titulo;
                            	                var textoEnviar = notas_fromJson[p].texto;
                            	                var datos = 'titulo=' + tituloEnviar + '&' + 'texto=' + textoEnviar;

                            	                //otro parámetro del Post refente a los caracteres
                            	                var config = {
                            	                    headers : {
                            	                        'Content-Type': 'application/x-www-form-urlencoded'
                            	                    }
                            	                }

                            	                //Hago el Post al PHP con el dato del LS que no está en la Base
                            	                //var ajax = $http.post("http://localhost/FinalLeonardoWeb2.0/php/guardar.php", datos, config);
                                                var ajax  = $http.post("http://www.cuantaskcal.com/beta/guardar.php", datos, config);
                            	                ajax.success(function(respuesta){
                            	                console.log(respuesta);
                            	                });

											}
                            	        }
                            	    }
							} else if( estado == '2') {

								//Piso los datos del LS. Con "angular.toJson()" lo que hago es pasar el
                                // Array de Objetos que me devolvió el php de la Base a un String como los que acepta el LS
                                localStorage.setItem("mis_notas", angular.toJson(data));

                                var notas_fromJson = data;

                                //Recorremos el Array de Objetos con un for. Por cada Objeto hacemos un push
                                // en nuestra Variable Global "$scope.datos_en_push"
                                for (var j = 0; j < notas_fromJson.length; j++) {
                                    $scope.datos_en_push.push(angular.copy(notas_fromJson[j]));
                                }

							} else if( estado == '3') {

                                //Obtengo los datos del LS y trabajo con eso
                                var notas_string = localStorage.getItem("mis_notas");

                                //Convierto el string del LS en array de Objetos
                                var notas_fromJson = angular.fromJson(notas_string);

                                //Lo recorro con un for y voy insertando en datos_en_push
                                    for (var p = 0; p < notas_fromJson.length; p++){
                                        $scope.datos_en_push.push(angular.copy(notas_fromJson[p]));
                                    }


                            } else if (estado == '4'){
								//No hay datos en DB ni en LS
                                $scope.datos_en_push ={idnota:"", titulo:"" , texto:""};
                            }
                        ///.error indica que no se pudo conectar con la base de datos
					}).error (function () {
						//Sólo me queda obtener los datos del LS y trabajar con eso
						var notas_string = localStorage.getItem("mis_notas");

						//si hay datos en el LS...
						if (notas_string != "undefined" && notas_string != null){

							//Convierto el string del LS en array de Objetos
							var notas_fromJson = angular.fromJson(notas_string);

							//Lo recorro con un for y voy insertando en datos_en_push
							for (var p = 0; p < notas_fromJson.length; p++){
								$scope.datos_en_push.push(angular.copy(notas_fromJson[p]));
							}
						}//si no hay datos en el LS...
							else{
							$scope.datos_en_push ={idnota:"", titulo:"" , texto:""};
						}
					}); //fin de .error cuando se pide el listado a la base

	$scope.guardar = function (detalles){

		//alert('Window LS ' + window.localStorage.getItem("mis_notas"));

        //alert('! Window LS ' + !window.localStorage.getItem("mis_notas"));

        if(!window.localStorage.getItem("mis_notas"))
			{
                $scope.datos_en_push=[];
            }
		else{
            $scope.datos_en_push = localStorage.getItem("mis_notas");
            $scope.datos_en_push = angular.fromJson($scope.datos_en_push);
        }

	//Definimos el Objeto/variable donde "cargamos" los datos enviados como parámetros
	var datos={//idnota: detalles.idnota,
	            idnota: 'pendiente_insert',
				titulo: detalles.titulo,
				texto: detalles.texto};

	//Insertamos con un push los nuevos datos en la variable global datos_en_push
	$scope.datos_en_push.push(datos);

	//Volvemos a convertir el Array de Objetos en string y pisamos la informacion del LS
	localStorage.setItem("mis_notas", JSON.stringify($scope.datos_en_push));

	//Inicializamos la variable para enviar como info del post
	var item = [];
        for(var i in detalles){
            item.push( i + '=' + detalles[i] );
        }
        //unimos los objetos del array con ampersand para ser enviado como dato
	var unir = item.join('&');
	console.log("Los datos " + unir);

        //Configuramos la cabecera del post
	var config = {
		headers : {
			'Content-Type': 'application/x-www-form-urlencoded'
		}
	}
        var ajax  = $http.post("http://www.cuantaskcal.com/beta/guardar.php", unir, config);

        $scope.notas.titulo = "";
        $scope.notas.texto = "";

        ajax.success(function(respuesta){
        console.log('Se guardó la nota - hubo conexión con la DB');
		var rta = respuesta;

	}).error (function () {
        console.log("No se pudo conectar a la Base de Datos");
        /*
        El dato se inserta en LS automáticamente, no es necesario hacer nada más

        var datos={idnota: 'pendiente_insert',
                   titulo: detalles.titulo,
                   texto: detalles.texto};

        var notas_string = localStorage.getItem("mis_notas");


        if (notas_string != "undefined" && notas_string != null){
              var notas_fromJson = JSON.parse(notas_string);
             for (var p = 0; p < notas_fromJson.length; p++){
              $scope.datos_en_push.push(angular.copy(notas_fromJson[p]));
             }
            $scope.datos_en_push.push(angular.copy(datos));
        }
        else{ $scope.datos_en_push ={ titulo:"" , texto:""};
        } */
    });

    }


    $scope.eliminar = function (id){

		console.log('ID a eliminar: ' + id.idnota);

		//Eliminar no funciona siempre bien, porque me falla a veces el splice del LS, por ende se vuelve a insertar
		//No pude solucionar la falla del splice. Pero no es siempre, a veces se elimina todo correctamente

		//Voy a eliminar ese dato del LS
        var notas_string = localStorage.getItem("mis_notas");
        var notas_fromJson = angular.fromJson(notas_string);
        var cont = 0;
        for (var p = 0; p < notas_fromJson.length; p++) {
            // Ahora voy a recorrer El Array de Obj de la Base (bucle anidado)

            if (id.idnota == notas_fromJson[p].idnota) {

                $scope.datos_en_push.splice(cont, 1);
                console.log('Hizo el splice');
            }

            cont++;
        }

        var datoId = id.idnota;

        var dato = 'idnota=' + datoId;

        console.log(dato);

        var config = {
            headers : {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        }


        var ajax  = $http.post("http://www.cuantaskcal.com/beta/eliminar.php", dato, config);
        //var ajax  = $http.post("http://localhost/FinalLeonardoWeb2.0/php/eliminar.php", dato, config);
        ajax.success(function(respuesta){
            if(respuesta == '1'){
            	console.log('eliminar ok'); //Nunca entra aquí porque el php devuelve mal la info
			} else {
                console.log('hubo un problema');
                /* Sea que se elimine correctamente o no siempre aparece esta opción, no lo pude solucionar.*/
			}

			;

        });

     //$scope.listar();

    }

    $scope.listar = function (datalista){

        $scope.datos_en_push = [];

        //$http.get("http://localhost/FinalLeonardoWeb2.0/php/listarnotas.php")
        $http.get("http://www.cuantaskcal.com/beta/listarnotas.php")
            .success(function (data) {

                localStorage.setItem("mis_notas", angular.toJson(data));
                var notas_fromJson = angular.fromJson(data);
                for (var j = 0; j < notas_fromJson.length; j++) {
                    $scope.datos_en_push.push(angular.copy(notas_fromJson[j]));

                }
			console.log('entro a listar scope, conectado a base');
            }).error (function (data) {

            var notas_string = localStorage.getItem("mis_notas");
            if (notas_string != "undefined" && notas_string != null){
                var notas_fromJson = JSON.parse(notas_string);
                for (var p = 0; p < notas_fromJson.length; p++){
                    $scope.datos_en_push.push(angular.copy(notas_fromJson[p]));
                }}
            else{$scope.datos_en_push ={ titulo:"" , texto:""};
            }

            console.log('entro a listar scope, No conectado, del local storage');

        });

    }
	
});


